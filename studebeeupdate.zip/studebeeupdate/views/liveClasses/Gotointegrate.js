// var request = require('request');
// var options = {
//   'method': 'POST',
//   'url': 'https://api.getgo.com//organizers',
//   'headers': {
//     'Content-Type': 'application/json',
//     'Accept': 'application/json'
//   },
//   body: JSON.stringify({"firstName":"Jubbub","lastName":"Larkin","organizerEmail":"jl@eName.com","productType":"G2M"})

// };
// request(options, function (error, response) {
//   if (error) throw new Error(error);
//   console.log(response.body);
// }